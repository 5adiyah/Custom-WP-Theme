<?php
get_header();
?>

<main>
    <?php get_template_part('template-parts/hero'); ?>
    <?php get_template_part('template-parts/content'); ?>
    <?php get_template_part('template-parts/contact'); ?>
</main>

<?php
get_footer();
?>
