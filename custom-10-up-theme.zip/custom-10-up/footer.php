<footer>
    <a href="<?php echo home_url(); ?>">
        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/10up_logo.svg" alt="10up Logo" class="logo-10up">
    </a>
</footer>
<?php wp_footer(); ?>
</body>
</html>
